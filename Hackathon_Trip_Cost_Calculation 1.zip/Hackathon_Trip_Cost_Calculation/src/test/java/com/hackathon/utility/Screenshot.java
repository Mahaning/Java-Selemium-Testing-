package com.hackathon.utility;

public class Screenshot {

}
